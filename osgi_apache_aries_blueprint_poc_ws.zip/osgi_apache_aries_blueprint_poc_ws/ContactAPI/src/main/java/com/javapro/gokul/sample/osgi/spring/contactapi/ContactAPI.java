package com.javapro.gokul.sample.osgi.spring.contactapi;

import java.util.List;

import com.javapro.gokul.sample.osgi.spring.contact.Contact;

public interface ContactAPI {
	public void startUp();
	public List getContactList();
	public Contact getContact(int contactId);
	public void insertContact(Contact contact);
	public void updateContact(Contact contact);
	public void deleteContact(int contactId);
}
