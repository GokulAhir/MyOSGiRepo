package com.javapro.gokul.osgi.spring;


//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;

import com.javapro.gokul.sample.osgi.spring.contact.*;
import com.javapro.gokul.sample.osgi.spring.contactapi.*;


public class HelloWorld{
	public HelloWorld(){
		System.out.println("Inside the constructor HelloWorld() of class Helloworld  : " + contactDAOServiceObj);
	}
	

	private ContactAPI contactDAOServiceObj;
	//private ContactDAO contactDAO;
	
	private Contact contact = new Contact();;
	
//	public ContactDAO getContactDAO() {
//		return contactDAO;
//	}
//
//	public void setContactDAO(ContactDAO contactDAO) {
//		System.out.println("Inside the setter method setContactDAO() of HelloWorld" );
//		this.contactDAO = contactDAO;
//		System.out.println("Inside the setter method setContactDAO() of HelloWorld  : " + contactDAO.toString());
//	}
//	
//	public Contact getContact() {
//		return contact;
//	}
//
//	public void setContact(Contact contact) {
//		System.out.println("Inside the setter method setContact() of HelloWorld" );
//		this.contact = contact;
//		System.out.println("Inside the setter method setContact() of HelloWorld  : "+contact.toString() );
//	}
	
	public ContactAPI getContactDAOServiceObj() {
		return contactDAOServiceObj;
	}

	public void setContactDAOServiceObj(ContactAPI contactDAOServiceObj) {
		System.out.println("Inside the setter method setContactDAOServiceObj() of HelloWorld" );
		this.contactDAOServiceObj = contactDAOServiceObj;
	}

	public void startUp(){
		try{
		System.out.println("Hello Welcome to Spring World!! ");
		System.out.println("Result of ContactDAO.getContactList()" + contactDAOServiceObj.getContactList()  );
		System.out.println("Contact with contactId " + contactDAOServiceObj.getContact(101));
		

//		Contact insertContact = new ContactDAOImpl();
//		insertContact.setContactId(4);
//		insertContact.setFirstName("Priya");
//		insertContact.setLastName("Sharma");

		contact.setContactId(4);
		contact.setFirstName("Priya");
		contact.setLastName("Sharma");
		contactDAOServiceObj.updateContact(contact);
		System.out.println("Result of ContactDAO.getContactList()" + contactDAOServiceObj.getContactList()  );
		
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void stop() {
		try{
			System.out.println("Goodbye Spring World!!");
		}catch(Exception e){
			e.printStackTrace();
		}
	}

//	@Override
//	public void actionPerformed(ActionEvent e) {
//		System.out.println("actionPerformed method HelloWorld is called... ");
//		System.out.println("Hello Welcome to Spring World!! ");
//		System.out.println("Result of ContactDAO.getContactList()" + contactDAOServiceObj.getContactList()  );
//		System.out.println("Contact with contactId " + contactDAOServiceObj.getContact(101));
//		
//		Contact insertContact = new Contact();
//		insertContact.setContactId(4);
//		insertContact.setFirstName("Priya");
//		insertContact.setLastName("Sharma");
//		contactDAOServiceObj.updateContact(insertContact);
//		System.out.println("Result of ContactDAO.getContactList()" + contactDAOServiceObj.getContactList()  );
//	}


}
