package com.javapro.gokul.sample.osgi.spring.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

//import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import com.javapro.gokul.sample.osgi.spring.contact.Contact;
import com.javapro.gokul.sample.osgi.spring.contactapi.ContactAPI;

public class ContactDAOImpl implements ContactAPI {

	//DataSource dataSource;
	BasicDataSource dataSourceObj;
	
	public BasicDataSource getDataSourceObj() {
		return dataSourceObj;
	}
	public void setDataSourceObj(BasicDataSource dataSourceObj) {
		this.dataSourceObj = dataSourceObj;
		System.out.println("Inside Setter Method setDataSource() of ContactDAOImpl : " +dataSourceObj);
	}
	@Override
	public void startUp() {
		System.out.println("##############Inside the startUp() method of class :ContactDAOImpl: ##############");
		System.out.println("================= Starting the ContactDAOImpl Service ===================");
		System.out.println("The ContactDAO Bundle is being started");
	}
	
	@Override
	public Contact getContact(int contactId) {
		System.out.println("Inside ContactDAOImpl.getContact()");
		Contact contact = new Contact();
		try {
			Connection connection = dataSourceObj.getConnection();
			System.out.println("GOT Connection Object inside getContact() method......");
			PreparedStatement stmt= connection.prepareStatement("SELECT * FROM CONTACT WHERE CONTACTID=?");
			stmt.setInt(1, contactId);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			String firstName = rs.getString("FIRSTNAME");
			String lastName = rs.getString("LASTNAME");
			contact.setContactId(contactId);
			contact.setFirstName(firstName);
			contact.setLastName(lastName);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return contact;
	}

	@Override
	public List getContactList() {
		System.out.println("Inside ContactDAOImpl.getContactList()");
		List contactList = new ArrayList();
		try {
			Connection connection = dataSourceObj.getConnection();
			System.out.println("GOT DB Connection inside getContactList() method");
			Statement stmt= connection.createStatement();
			ResultSet rs =stmt.executeQuery("SELECT * FROM CONTACT");
			while(rs.next()){
				int contactId = rs.getInt("CONTACTID");
				String firstName = rs.getString("FIRSTNAME");
				String lastName = rs.getString("LASTNAME");
				Contact contact = new Contact(contactId,firstName,lastName);
				contactList.add(contact);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return contactList;
	}

	@Override
	public void deleteContact(int contactId) {
		try {
			Connection connection = dataSourceObj.getConnection();
			System.out.println("GOT DB Connection inside deleteContact() method");
			PreparedStatement stmt = connection.prepareStatement("DELETE FROM CONTACT WHERE CONTACTID=?");
			stmt.setInt(1, contactId);
			stmt.execute();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}

	@Override
	public void insertContact(Contact contact) {
		try {
			Connection connection = dataSourceObj.getConnection();
			System.out.println("GOT DB Connection inside insertContact() method");
			PreparedStatement stmt = connection.prepareStatement("INSERT INTO CONTACT VALUES (?,?,?,?)"); 
			stmt.setInt(1, contact.getContactId());
			stmt.setString(2, contact.getFirstName());
			stmt.setString(3, contact.getLastName());
			stmt.setString(4, "");
			stmt.execute();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}

	@Override
	public void updateContact(Contact contact) {
		try {
			Connection connection = dataSourceObj.getConnection();
			System.out.println("GOT DB Connection inside updateContact() method");
			PreparedStatement stmt = connection.prepareStatement("Update contact set FIRSTNAME=?, LASTNAME=? where contactid=?"); 
			stmt.setInt(3, contact.getContactId());
			stmt.setString(1, contact.getFirstName());
			stmt.setString(2, contact.getLastName());
			stmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		
	}

}
